# frozen_string_literal: true

module RuboCop
  module Airbnb
    # Version information for the the Airbnb RuboCop plugin.
    VERSION = '3.0.2'
  end
end
